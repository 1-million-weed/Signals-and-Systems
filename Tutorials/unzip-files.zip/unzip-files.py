import zipfile
import os

def unzip_file(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)

def main():
    zip_files = ['data/fma_metadata.zip', 'data/fma_small.zip']

    for zip_file in zip_files:
        extract_to = os.path.splitext(zip_file)[0]  # Extract to a folder with the same name as the zip file
        if not os.path.exists(extract_to):
            os.makedirs(extract_to)

        unzip_file(zip_file, extract_to)
        print(f'Unzipped {zip_file} to {extract_to}')

if __name__ == "__main__":
    main()
